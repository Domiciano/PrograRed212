package provider;

import db.MySQL;
import model.Task;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class TaskProvider {

    public void addTask(Task task) throws SQLException, ClassNotFoundException {
        MySQL db = new MySQL();
        String sql = ("INSERT INTO A00361998Task (title, description, category, date)" +
                "VALUES ($TILE,$DESCRIPTION,$CATEGORY,$DATE)")
                .replace("$TITLE", "'" + task.getTitle() + "'")
                .replace("$DESCRIPTION", "'" + task.getDescription() + "'")
                .replace("$CATEGORY", "'" + task.getCategory() + "'")
                .replace("$DATE", "'" + task.getDate() + "'");
        db.connect();
        db.commandSQL(sql);
        db.disconnect();
    }

    public void deleteTask(int id) throws ClassNotFoundException, SQLException {
        MySQL db = new MySQL();
        String sql = ("DELETE FROM A00361998Task WHERE id=$ID").replace("$ID",""+id);
        db.connect();
        db.commandSQL(sql);
        db.disconnect();
    }

    public void updateCategory(Task task) throws ClassNotFoundException, SQLException {
        MySQL db = new MySQL();
        String sql = ("UPDATE A00361998Task SET category=$CATEGORY WHERE id=$ID")
                .replace("$ID", "" + task.getId())
                .replace("$CATEGORY", "'" + task.getCategory() + "'");
        db.connect();
        db.commandSQL(sql);
        db.disconnect();
    }

    public Task getTask(int id) throws ClassNotFoundException, SQLException {
        String sql = "SELECT * FROM A00361998Task WHERE id=$ID".replace("$ID",""+id);
        MySQL db = new MySQL();
        db.connect();
        ResultSet resultSet = db.getDataBySQL(sql);
        Task task = null;
        while(resultSet.next()){
            String title = resultSet.getString(resultSet.findColumn("title"));
            String description = resultSet.getString(resultSet.findColumn("description"));
            String category = resultSet.getString(resultSet.findColumn("category"));
            String date = resultSet.getString(resultSet.findColumn("date"));
            task = new Task(id,title,description,category,date);
        }
        db.disconnect();
        return task;
    }

    public ArrayList<Task> getAllTaskToDo() throws SQLException, ClassNotFoundException {
        String sql= "SELECT * FROM A00361998Tasks WHERE category="+"'"+"To-Do"+"'";
        MySQL db = new MySQL();
        db.connect();
        ArrayList<Task> allTask = new ArrayList<Task>();
        ResultSet resultSet =  db.getDataBySQL(sql);
        while(resultSet.next()) {
            int id = Integer.parseInt(resultSet.getString(resultSet.findColumn("id")));
            String title = resultSet.getString(resultSet.findColumn("title"));
            String description = resultSet.getString(resultSet.findColumn("description"));
            String category = resultSet.getString(resultSet.findColumn("category"));
            String date = resultSet.getString(resultSet.findColumn("date"));
            allTask.add(new Task(id, title, description,category,date));
        }
        db.disconnect();
        return allTask;
    }

    public ArrayList<Task> getAllTaskDoing() throws SQLException, ClassNotFoundException {
        String sql= "SELECT * FROM A00361998Tasks WHERE category="+"'"+"Doing"+"'";
        MySQL db = new MySQL();
        db.connect();
        ArrayList<Task> allTask = new ArrayList<Task>();
        ResultSet resultSet =  db.getDataBySQL(sql);
        while(resultSet.next()) {
            int id = Integer.parseInt(resultSet.getString(resultSet.findColumn("id")));
            String title = resultSet.getString(resultSet.findColumn("title"));
            String description = resultSet.getString(resultSet.findColumn("description"));
            String category = resultSet.getString(resultSet.findColumn("category"));
            String date = resultSet.getString(resultSet.findColumn("date"));
            allTask.add(new Task(id, title, description,category,date));
        }
        db.disconnect();
        return allTask;
    }
    public ArrayList<Task> getAllTasksDone() throws SQLException, ClassNotFoundException {
        String sql= "SELECT * FROM A00361998Tasks WHERE category="+"'"+"Done"+"'";
        MySQL db = new MySQL();
        db.connect();
        ArrayList<Task> allTask = new ArrayList<Task>();
        ResultSet resultSet =  db.getDataBySQL(sql);
        while(resultSet.next()) {
            int id = Integer.parseInt(resultSet.getString(resultSet.findColumn("id")));
            String title = resultSet.getString(resultSet.findColumn("title"));
            String description = resultSet.getString(resultSet.findColumn("description"));
            String category = resultSet.getString(resultSet.findColumn("category"));
            String date = resultSet.getString(resultSet.findColumn("date"));
            allTask.add(new Task(id, title, description,category,date));
        }
        db.disconnect();
        return allTask;
    }

}
