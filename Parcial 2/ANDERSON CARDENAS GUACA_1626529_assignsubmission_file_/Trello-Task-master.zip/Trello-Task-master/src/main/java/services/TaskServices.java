package services;

import model.Task;
import provider.TaskProvider;

import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import java.sql.SQLException;
import java.util.ArrayList;

@Path("task")
public class TaskServices {

    @POST
    @Consumes("application/json")
    @Path("add")
    public Response addTask(Task taskObj) {
        try {
            TaskProvider provider = new TaskProvider();
            provider.addTask(taskObj);
            return Response
                    .status(200)
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return Response
                    .status(200)
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }
    }

    @DELETE
    @Consumes("application/json")
    @Path("delete/{taskId}")
    public Response deleteTask(@PathParam("taskId") int taskId){
        try {
            TaskProvider provider = new TaskProvider();
            provider.deleteTask(taskId);
            return Response
                    .status(200)
                    .header("Access-Control-Allow-Origin", "*")
                    .build();

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return Response
                    .status(500)
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }
    }

    @PUT
    @Consumes("application/json")
    @Path("update")
    public Response updateCategory(Task taskObj){
        try {
            TaskProvider provider = new TaskProvider();
            provider.updateCategory(taskObj);
            return Response
                    .status(200)
                    .header("Access-Control-Allow-Origin", "*")
                    .build();

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return Response
                    .status(500)
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }
    }

    @GET
    @Produces("application/json")
    @Consumes("application/json")
    @Path("getAllToDo")
    public Response getAllTaskToDo(){
        try{
            TaskProvider provider = new TaskProvider();
            ArrayList<Task> tasks = provider.getAllTaskToDo();
            return Response
                    .status(200)
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return Response
                    .status(500)
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }
    }

    @GET
    @Produces("application/json")
    @Consumes("application/json")
    @Path("getAllDoing")
    public Response getAllTaskDoing(){
        try{
            TaskProvider provider = new TaskProvider();
            ArrayList<Task> tasks = provider.getAllTaskDoing();
            return Response
                    .status(200)
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return Response
                    .status(500)
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }
    }

    @GET
    @Produces("application/json")
    @Consumes("application/json")
    @Path("getAllDone")
    public Response getAllTaskDone(){
        try{
            TaskProvider provider = new TaskProvider();
            ArrayList<Task> tasks = provider.getAllTasksDone();
            return Response
                    .status(200)
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return Response
                    .status(500)
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }
    }
}
