class UpdateCategory{

    constructor(id, category){
        this.id = id;
        this.category = category;
    }

}