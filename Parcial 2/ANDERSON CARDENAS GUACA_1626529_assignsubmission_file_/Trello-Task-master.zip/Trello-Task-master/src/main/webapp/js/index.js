const createBtn = document.getElementById('createTaskBtn');
const title = document.getElementById('titleTask');
const description = document.getElementById('descriptionTask');
const toDoContainer = document.getElementById('ToDo');
const doingContainer = document.getElementById('Doing');
const doneContainer = document.getElementById('Done');

const getTask =(container, title, id) =>{
    let xhr = new XMLHttpRequest();
    xhr.addEventListener('readystatechange', ()=>{
        if(xhr.readyState === 4){
            let json = xhr.responseText;
            let response = JSON.parse(json);
            console.log(response);
            let taskDto = response;
            let view = new TaskView(taskDto);
            view.oneDelete = ()=>{
                container.removeChild(document.getElementById('taskCard-'+taskDto.id));
            };
            container.appendChild(view.render());
        }
    });
    xhr.open("GET", "http://localhost:8080/Trello/api/task/" + id);
    xhr.send();
}

const getAllTask=()=>{
    getAllTasksFrom(toDoContainer,'getAllToDo','To Do');
    getAllTasksFrom(doingContainer,'getAllDoing', 'Doing');
    getAllTasksFrom(doneContainer,'getAllDone', 'Done');
}

const getAllTasksFrom = (container,path,title) =>{
    let xhr = new XMLHttpRequest();
    xhr.addEventListener('readystatechange', ()=>{
        if(xhr.readyState === 4){
            let json = xhr.responseText;
            let response = JSON.parse(json);

            container.innerHTML = '';
            let pat = document.createElement('h4');
            pat.innerHTML = title;
            container.appendChild(pat);
            for(let i=0 ; i<response.length ; i++){
                let taskDTO = response[i];
                let view = new TaskView(taskDTO);
                view.oneDelete = () =>{
                    container.removeChild(document.getElementById('taskCard-' + taskDTO.id));////////////
                };
                container.appendChild(view.render());
            }
        }
    });
    xhr.open("GET", "http://localhost:8080/Trello/api/task/" + path);
    xhr.send();
}
getAllTask();

const addTask = () => {
    let tday = new Date();
    let date = tday.getFullYear() + '-' + (tday.getMonth() + 1) + '-' + tday.getDate();
    const task = new Task(title.value, description.value, "To-Do", date);
    let xhr = new XMLHttpRequest();
    xhr.addEventListener('readystatechange', ()=>{
        if(xhr.readyState ===4 ){
            console.log(xhr.responseText);
        }
    })
    xhr.open("POST", "http://localhost:8080/Trello/api/task/add");
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(task));
    const clean = () => {
        document.getElementById('titleTask').value = "";
        document.getElementById('descriptionTask').value = "";
    };
    clean();
    getAllTask();
};

createBtn.addEventListener('click', addTask);

toDoContainer.addEventListener('dragover', e=>{
    e.preventDefault();
    e.target.classList.add('hover');
});

toDoContainer.addEventListener('dragleave', e=>{
    e.target.classList.remove('hover');
});

toDoContainer.addEventListener('drop', e=>{
    e.target.classList.remove('hover');
    const id = e.dataTransfer.getData('id');
    const number = id.split('-')[1];
    var element = document.getElementById(id);
    element.parentNode.removeChild(element);

    const update = new UpdateCategory(number, "To-Do");
    let xhr = new XMLHttpRequest();
    xhr.addEventListener('readystatechange', ()=>{
        if(xhr.readyState ===4 ){
            console.log(xhr.responseText);
            getTask(toDoContainer, 'To Do', number);
        }
    })
    xhr.open("PUT", "http://localhost:8080/Trello/api/task/update");
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(update));
    console.log(JSON.stringify(update));
});

doingContainer.addEventListener('dragover', e=>{
    e.preventDefault();
    e.target.classList.add('hover');
});

doingContainer.addEventListener('dragleave', e=>{
    e.target.classList.remove('hover');
});

doingContainer.addEventListener('drop', e=>{
    e.target.classList.remove('hover');
    const id = e.dataTransfer.getData('id');
    const number = id.split('-')[1];
    var element = document.getElementById(id);
    element.parentNode.removeChild(element);

    const update = new UpdateCategory(number, "Doing");
    let xhr = new XMLHttpRequest();
    xhr.addEventListener('readystatechange', ()=>{
        if(xhr.readyState ===4 ){
            console.log(xhr.responseText);
            getTask(doingContainer, 'Doing', number);
        }
    })
    xhr.open("PUT", "http://localhost:8080/Trello/api/task/update");
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(update));
    console.log(JSON.stringify(update));
});

doneContainer.addEventListener('dragover', e=>{
    e.preventDefault();
    e.target.classList.add('hover');
});

doneContainer.addEventListener('dragleave', e=>{
    e.target.classList.remove('hover');
});

doneContainer.addEventListener('drop', e=>{
    e.target.classList.remove('hover');
    const id = e.dataTransfer.getData('id');
    const number = id.split('-')[1];
    var element = document.getElementById(id);
    element.parentNode.removeChild(element);

    const update = new UpdateCategory(number, "Done");
    let xhr = new XMLHttpRequest();
    xhr.addEventListener('readystatechange', ()=>{
        if(xhr.readyState ===4 ){
            console.log(xhr.responseText);
            getTask(doneContainer, 'Done', number);
        }
    })
    xhr.open("PUT", "http://localhost:8080/Trello/api/task/update");
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(update));
    console.log(JSON.stringify(update));
});