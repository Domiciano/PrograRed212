package provider;

import db.MySQL;
import entity.Task;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;

public class TaskProvider {

    public void create(Task task) throws ClassNotFoundException, SQLException {
        MySQL db = new MySQL();
        db.connect();
        String sql = "INSERT INTO A00364415Tasks(taskID, title, info, taskDate, type) VALUES ('$TID', '$TITLE', '$INFO', $TASKDATE, '$TYPE')";
        long date = System.currentTimeMillis() / 1000L;
        sql = sql.replace("$TID", UUID.randomUUID().toString());
        sql = sql.replace("$TITLE", task.getTitle());
        sql = sql.replace("$INFO", task.getInfo());
        sql = sql.replace("$TASKDATE", "FROM_UNIXTIME("+date+")");
        sql = sql.replace("$TYPE", "TO DO");

        db.commandSQL(sql);
        db.close();
    }

    public void forwardTaskStatus(String taskID) throws ClassNotFoundException, SQLException {
        MySQL db = new MySQL();
        db.connect();

        String sql = "SELECT type FROM A00364415Tasks WHERE taskID = '$TID'";
        sql = sql.replace("$TID", taskID);
        ResultSet resultSet = db.getDataBySQL(sql);
        resultSet.next();
        String currentState = resultSet.getString(1);
        String sqlUpdate = "";

        if(currentState.equalsIgnoreCase("TO DO")){
            //En caso de ser TO DO lo pasa a DOING
            sqlUpdate = "UPDATE A00364415Tasks SET type = 'DOING' WHERE taskID = '$TID'";
            sqlUpdate = sqlUpdate.replace("$TID", taskID);
        } else if(currentState.equalsIgnoreCase("DOING")){
            //En caso de ser DOING lo pasa a DONE y gg
            sqlUpdate = "UPDATE A00364415Tasks SET type = 'DONE' WHERE taskID = '$TID'";
            sqlUpdate = sqlUpdate.replace("$TID", taskID);
        }

        db.commandSQL(sqlUpdate);
        db.close();



    }

    public ArrayList<Task> getByType(int option) throws ClassNotFoundException, SQLException {
        MySQL db = new MySQL();
        db.connect();
        ArrayList<Task> tasks = new ArrayList<>();
        String sql = "SELECT * FROM A00364415Tasks WHERE type = '$TTYPE' ";

       switch (option){
           case 1:
               sql = sql.replace("$TTYPE", "TO DO");
           break;
           case 2:
               sql = sql.replace("$TTYPE", "DOING");
           break;
           case 3:
               sql = sql.replace("$TTYPE", "DONE");
           break;
           default:
               sql = sql.replace("$TTYPE", "TO DO");
           break;
       }
        ResultSet resultSet = db.getDataBySQL(sql);

    while(resultSet.next()){
        tasks.add(new Task(
                resultSet.getString(2),
                resultSet.getString(3),
                resultSet.getString(4),
                resultSet.getString(5),
                resultSet.getString(6)
        ));
    }

        db.close();
        return tasks;

    }

    public void delete(String taskID) throws ClassNotFoundException, SQLException {
        MySQL db = new MySQL();
        db.connect();

        String sql = "DELETE FROM A00364415Tasks WHERE taskID = '$TID'";
        sql = sql.replace("$TID", taskID);

        db.commandSQL(sql);
        db.close();
    }

    public void backwardTaskStatus(String taskID) throws ClassNotFoundException, SQLException {
        MySQL db = new MySQL();
        db.connect();

        String sql = "SELECT type FROM A00364415Tasks WHERE taskID = '$TID'";
        sql = sql.replace("$TID", taskID);
        ResultSet resultSet = db.getDataBySQL(sql);
        resultSet.next();
        String currentState = resultSet.getString(1);
        String sqlUpdate = "";

        if(currentState.equalsIgnoreCase("DONE")){
            //En caso de ser DONE lo pasa a DOING
            sqlUpdate = "UPDATE A00364415Tasks SET type = 'DOING' WHERE taskID = '$TID'";
            sqlUpdate = sqlUpdate.replace("$TID", taskID);
        } else if(currentState.equalsIgnoreCase("DOING")){
            //En caso de ser DOING lo pasa a TO DO
            sqlUpdate = "UPDATE A00364415Tasks SET type = 'TO DO' WHERE taskID = '$TID'";
            sqlUpdate = sqlUpdate.replace("$TID", taskID);
        }

        db.commandSQL(sqlUpdate);
        db.close();
    }
}
