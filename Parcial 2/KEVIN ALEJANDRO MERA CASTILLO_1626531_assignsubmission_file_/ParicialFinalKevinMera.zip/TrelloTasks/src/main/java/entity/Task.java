package entity;

import java.util.Date;

public class Task {
    private String taskID;
    private String title;
    private String info;
    private String taskDate;
    private String type;

    public Task(){

    }

    public Task(String taskID, String title, String info, String taskDate, String type) {
        this.taskID = taskID;
        this.title = title;
        this.info = info;
        this.taskDate = taskDate;
        this.type = type;
    }

    public String getTaskID() {
        return taskID;
    }

    public void setTaskID(String taskID) {
        this.taskID = taskID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getTaskDate() {
        return taskDate;
    }

    public void setTaskDate(String taskDate) {
        this.taskDate = taskDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
