package services;

import entity.Message;
import entity.Task;
import provider.TaskProvider;

import javax.ejb.Stateless;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import java.sql.SQLException;
import java.util.ArrayList;

@Path("tasks")
@Stateless
public class TaskService {


    @OPTIONS
    @Path("create")
    public Response options(Task task){
        return Response.status(200)
                .header("access-control-allow-origin", "*")
                .header("access-control-allow-methods", "*")
                .header("access-control-allow-headers", "*")
                .build();
    }

    @POST
    @Path("create")
    @Consumes("application/json")
    public Response create(Task task){
        try {
            TaskProvider provider = new TaskProvider();
            provider.create(task);
            return Response.status(200)
                    .header("access-control-allow-origin", "*")
                    .header("access-control-allow-methods", "*")
                    .header("access-control-allow-headers", "*")
                    .entity(new Message("tarea creada correctamente")).build();
        }catch (ClassNotFoundException | SQLException ex){
            return Response.status(500)
                    .header("access-control-allow-origin", "*")
                    .header("access-control-allow-methods", "*")
                    .header("access-control-allow-headers", "*")
                    .entity(new Message(ex.getMessage())).build();
        }
    }

    @GET
    @Path("getbytype/{option}")
    @Produces("application/json")
    public Response getByType(@PathParam("option") int option){
        try {
            TaskProvider provider = new TaskProvider();
            ArrayList<Task> tasks = provider.getByType(option);
            return Response.status(200).header("access-control-allow-origin", "*").entity(tasks).build();
        } catch (SQLException | ClassNotFoundException ex) {
            return Response.status(500).header("access-control-allow-origin", "*").entity(new Message(ex.getMessage())).build();
        }
    }

    @GET
    @Path("forwardstatus/{taskid}")
    @Produces("application/json")
    public Response forwardTaskStatus(@PathParam("taskid") String taskID){
        try {
            TaskProvider provider = new TaskProvider();
            provider.forwardTaskStatus(taskID);
            return Response.ok(new Message("Tarea actualizada"))
                    .header("Content-Type", "application/json")
                    .header("access-control-allow-origin", "*")
                    .build();
        } catch (SQLException | ClassNotFoundException ex) {
            return Response.status(500).header("access-control-allow-origin", "*").entity(new Message(ex.getMessage())).build();
        }
    }

    @GET
    @Path("backwardstatus/{taskid}")
    @Produces("application/json")
    public Response backwardTaskStatus(@PathParam("taskid") String taskID){
        try {
            TaskProvider provider = new TaskProvider();
            provider.backwardTaskStatus(taskID);
            return Response.ok(new Message("Tarea actualizada"))
                    .header("Content-Type", "application/json")
                    .header("access-control-allow-origin", "*")
                    .build();
        } catch (SQLException | ClassNotFoundException ex) {
            return Response.status(500).header("access-control-allow-origin", "*").entity(new Message(ex.getMessage())).build();
        }
    }

    @DELETE
    @Path("deletetask/{taskid}")
    @Produces("application/json")
    public Response deleteTask(@PathParam("taskid") String taskID){
        try {
            TaskProvider provider = new TaskProvider();
            provider.delete(taskID);
            return Response.ok(new Message("Tarea eliminada exitosamente"))
                    .header("Access-Control-Allow-Origin", "*")
                    .header("Content-Type", "application/json")
                    .build();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return Response.status(500)
                    .entity(new Message("Operacion fallida"))
                    .header("Access-Control-Allow-Origin", "*")
                    .header("Content-Type", "application/json")
                    .build();
        }
    }

}
