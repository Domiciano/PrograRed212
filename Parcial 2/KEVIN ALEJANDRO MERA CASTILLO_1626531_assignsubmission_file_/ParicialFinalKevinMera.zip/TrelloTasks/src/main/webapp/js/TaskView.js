class TaskView{



    //State
    constructor(task){
        this.task = task;
        this.onForwardDone = null;
        this.onBackwardDone = null;
        this.onDeleteDone = null;
        this.onLoad = null;
        Object.seal(this);
    }


        //Metodos
        render = (container, option)=>{
            //String -> HTML DOM
    
            let component = document.createElement("div"); //DOM
            let html = "";
            let card = "";
            let deleteBtn = "";
            let backBtn = "";
            let nextBtn = "";
            switch (option) {
                case 1:

                    component.id = 'task'+this.task.taskID;
                    html = `<div id="${this.task.taskID}" class="card text-dark bg-light border-info mb-3" style="max-width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title">${this.task.title}</h5>
                        <p class="card-text">${this.task.info}</p>
                        <h6 class="card-date">${this.task.taskDate}</h6>
                        
                    </div>
                    <div class = "buttons-control">
                    <button id="delete/${this.task.taskID}" href="#" class="btn btndelete btn-outline-danger btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                    <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"></path>
                    <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"></path>
                  </svg>
                  
                  
                  </button>

                    <button id="forward/${this.task.taskID}" href="#" class="btn btnforWard btn-outline-primary btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right-square-fill" viewBox="0 0 16 16">
                    <path d="M0 14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2a2 2 0 0 0-2 2v12zm4.5-6.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5a.5.5 0 0 1 0-1z"></path>
                  </svg>
                  
                  
                  </button>
                    </div>
                    
                </div>`;
                    component.innerHTML = html; //<div> <div class="card">...</div> </div>

                    //text-white bg-secondary

                    card = component.firstChild; // <div class="card">...</div> DOM HTML

                    container.appendChild(card);

                    //Eventos a la card
                    deleteBtn = document.getElementById("delete/" + this.task.taskID);
                    deleteBtn.addEventListener("click", this.delete);

                    nextBtn = document.getElementById("forward/" + this.task.taskID);
                    nextBtn.addEventListener("click", this.forward);
                    
                    break;
            
                case 2:

                    component.id = 'task'+this.task.taskID;
                    html = `<div id="${this.task.taskID}" class="card text-dark bg-light border-info mb-3" style="max-width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title">${this.task.title}</h5>
                        <p class="card-text">${this.task.info}</p>
                        <h6 class="card-date">${this.task.taskDate}</h6>
                        
                    </div>
                    <div class = "buttons-control">
                    <button id="backward/${this.task.taskID}" href="#" class="btn btnbackward btn-outline-warning btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-square-fill" viewBox="0 0 16 16">
                    <path d="M16 14a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12zm-4.5-6.5H5.707l2.147-2.146a.5.5 0 1 0-.708-.708l-3 3a.5.5 0 0 0 0 .708l3 3a.5.5 0 0 0 .708-.708L5.707 8.5H11.5a.5.5 0 0 0 0-1z"></path>
                  </svg>
                    

                  </button>


                    <button id="delete/${this.task.taskID}" href="#" class="btn btndelete btn-outline-danger btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                    <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"></path>
                    <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"></path>
                  </svg>
                  
                  
                  </button>

                    <button id="forward/${this.task.taskID}" href="#" class="btn btnforWard btn-outline-primary btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right-square-fill" viewBox="0 0 16 16">
                    <path d="M0 14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2a2 2 0 0 0-2 2v12zm4.5-6.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5a.5.5 0 0 1 0-1z"></path>
                  </svg>
                  

                  </button>

                    </div>
                    
                </div>`;
                    component.innerHTML = html; //<div> <div class="card">...</div> </div>

                    //text-white bg-secondary

                    card = component.firstChild; // <div class="card">...</div> DOM HTML

                    container.appendChild(card);

                    //Eventos a la card
                    deleteBtn = document.getElementById("delete/" + this.task.taskID);
                    deleteBtn.addEventListener("click", this.delete);
                    

                    backBtn = document.getElementById("backward/" + this.task.taskID);
                    backBtn.addEventListener("click", this.backward);

                    nextBtn = document.getElementById("forward/" + this.task.taskID);
                    nextBtn.addEventListener("click", this.forward);

                    break;

                case 3:

                    component.id = 'task'+this.task.taskID;
                    html = `<div id="${this.task.taskID}" class="card text-dark bg-light border-info mb-3" style="max-width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title">${this.task.title}</h5>
                        <p class="card-text">${this.task.info}</p>
                        <h6 class="card-date">${this.task.taskDate}</h6>
                        
                    </div>
                    <div class = "buttons-control">
                    <button id="backward/${this.task.taskID}" href="#" class="btn btnbackward btn-outline-warning btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-square-fill" viewBox="0 0 16 16">
                    <path d="M16 14a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12zm-4.5-6.5H5.707l2.147-2.146a.5.5 0 1 0-.708-.708l-3 3a.5.5 0 0 0 0 .708l3 3a.5.5 0 0 0 .708-.708L5.707 8.5H11.5a.5.5 0 0 0 0-1z"></path>
                  </svg>
                    

                  </button>
                  <button id="delete/${this.task.taskID}" href="#" class="btn btndelete btn-outline-danger btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"></path>
                  <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"></path>
                </svg>
                
                
                </button>
                    </div>
                    
                </div>`;


                    component.innerHTML = html; //<div> <div class="card">...</div> </div>

                    //text-white bg-secondary

                    card = component.firstChild; // <div class="card">...</div> DOM HTML

                    container.appendChild(card);

                    //Eventos a la card
                    deleteBtn = document.getElementById("delete/" + this.task.taskID);
                    deleteBtn.addEventListener("click", this.delete);
                    
                        

                    backBtn = document.getElementById("backward/" + this.task.taskID);
                    backBtn.addEventListener("click", this.backward);

                    break;

                default:
                    break;
            }

        }

        renderLoad = (option)=>{
            //String -> HTML DOM
    
            let component = document.createElement("div"); //DOM
            let html = "";
            let card = "";
            let deleteBtn = "";
            let backBtn = "";
            let nextBtn = "";
            switch (option) {
                case 1:

                    component.id = 'task'+this.task.taskID;
                    html = `<div class="card text-dark bg-light border-info mb-3" aria-hidden="true" style="max-width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title placeholder-glow">
                        <span class="placeholder col-6"></span>
                        </h5>
                        <p class="card-text placeholder-glow">
                        <span class="placeholder col-7"></span>
                        <span class="placeholder col-4"></span>
                        <span class="placeholder col-4"></span>
                        <span class="placeholder col-6"></span>
                        <span class="placeholder col-8"></span>
                        </p>
                        <h6 class="card-date placeholder-glow">
                        <span class="placeholder col-7"></span>
                        </h6>
                        
                    </div>
                    <div class = "buttons-control placeholder-glow">
                    <button id="delete/${this.task.taskID}" href="#" class="btn btndelete disabled placeholder btn-outline-danger btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                    <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"></path>
                    <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"></path>
                  </svg>
                    
                    
                    </button>

                    <button id="forward/${this.task.taskID}" href="#" class="btn btnforWard disabled placeholder btn-outline-primary btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right-square-fill" viewBox="0 0 16 16">
                    <path d="M0 14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2a2 2 0 0 0-2 2v12zm4.5-6.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5a.5.5 0 0 1 0-1z"></path>
                  </svg>
                  

                  </button>
                    </div>
                    
                </div>`;
                    component.innerHTML = html; //<div> <div class="card">...</div> </div>

                    //text-white bg-secondary

                    card = component.firstChild; // <div class="card">...</div> DOM HTML

                    
                    break;
            
                case 2:

                    component.id = 'task'+this.task.taskID;
                    html = `<div class="card text-dark bg-light border-info mb-3" aria-hidden="true" style="max-width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title placeholder-glow">
                        <span class="placeholder col-6"></span>
                        </h5>
                        <p class="card-text placeholder-glow">
                        <span class="placeholder col-7"></span>
                        <span class="placeholder col-4"></span>
                        <span class="placeholder col-4"></span>
                        <span class="placeholder col-6"></span>
                        <span class="placeholder col-8"></span>
                        </p>
                        <h6 class="card-date placeholder-glow">
                        <span class="placeholder col-7"></span>
                        </h6>
                        
                    </div>
                    <div class = "buttons-control placeholder-glow">
                    <button id="backward/${this.task.taskID}" href="#" class="btn btnbackward disabled placeholder btn-outline-warning btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-square-fill" viewBox="0 0 16 16">
                    <path d="M16 14a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12zm-4.5-6.5H5.707l2.147-2.146a.5.5 0 1 0-.708-.708l-3 3a.5.5 0 0 0 0 .708l3 3a.5.5 0 0 0 .708-.708L5.707 8.5H11.5a.5.5 0 0 0 0-1z"></path>
                  </svg>
                    

                  </button>
                  <button id="delete/${this.task.taskID}" href="#" class="btn btndelete disabled placeholder btn-outline-danger btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"></path>
                  <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"></path>
                </svg>
                  
                  
                  </button>

                    <button id="forward/${this.task.taskID}" href="#" class="btn btnforWard disabled placeholder btn-outline-primary btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right-square-fill" viewBox="0 0 16 16">
                    <path d="M0 14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2a2 2 0 0 0-2 2v12zm4.5-6.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5a.5.5 0 0 1 0-1z"></path>
                  </svg>
                  

                  </button>

                    </div>
                    
                </div>`;
                    component.innerHTML = html; //<div> <div class="card">...</div> </div>

                    //text-white bg-secondary

                    card = component.firstChild; // <div class="card">...</div> DOM HTML

                    break;

                case 3:

                    component.id = 'task'+this.task.taskID;
                    html = `<div class="card text-dark bg-light border-info mb-3" aria-hidden="true" style="max-width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title placeholder-glow">
                        <span class="placeholder col-6"></span>
                        </h5>
                        <p class="card-text placeholder-glow">
                        <span class="placeholder col-7"></span>
                        <span class="placeholder col-4"></span>
                        <span class="placeholder col-4"></span>
                        <span class="placeholder col-6"></span>
                        <span class="placeholder col-8"></span>
                        </p>
                        <h6 class="card-date placeholder-glow">
                        <span class="placeholder col-7"></span>
                        </h6>
                        
                    </div>
                    <div class = "buttons-control placeholder-glow">
                    <button id="backward/${this.task.taskID}" href="#" class="btn btnbackward disabled placeholder btn-outline-warning btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-square-fill" viewBox="0 0 16 16">
                    <path d="M16 14a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12zm-4.5-6.5H5.707l2.147-2.146a.5.5 0 1 0-.708-.708l-3 3a.5.5 0 0 0 0 .708l3 3a.5.5 0 0 0 .708-.708L5.707 8.5H11.5a.5.5 0 0 0 0-1z"></path>
                  </svg>
                    

                  </button>
                  <button id="delete/${this.task.taskID}" href="#" class="btn btndelete disabled placeholder btn-outline-danger btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"></path>
                  <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"></path>
                </svg>
                
                
                </button>
                    </div>
                    
                </div>`;


                    component.innerHTML = html; //<div> <div class="card">...</div> </div>

                    //text-white bg-secondary

                    card = component.firstChild; // <div class="card">...</div> DOM HTML

                    break;

                default:
                    break;
            }

            return card;

        }
            

    delete = ()=>{
        this.onLoad();
        let xhr = new XMLHttpRequest();
        xhr.addEventListener('readystatechange', ()=>{
            if(xhr.readyState == 4){
                var response = JSON.parse(xhr.responseText);
                console.log(response.message);
                if(response.message == 'Tarea eliminada exitosamente'){
                    if(this.onDeleteDone() != null){
                        this.onDeleteDone();
                    }
                } else {
                    alert('No se pudo eliminar la tarea');
                }
            }
        });
    xhr.open('DELETE', 'api/tasks/deletetask/'+this.task.taskID);
    xhr.send();

    }    
    

    forward = ()=>{
        this.onLoad();
        let xhr = new XMLHttpRequest();
        xhr.addEventListener('readystatechange', ()=>{
            if(xhr.readyState == 4){
                var response = JSON.parse(xhr.responseText);
                console.log(response.message);
                if(response.message == 'Tarea actualizada'){
                    if(this.onForwardDone() != null){
                        this.onForwardDone();
                    }
                } else {
                    alert('No se pudo avanzar la tarea');
                }
            }
        });
    xhr.open('GET', 'api/tasks/forwardstatus/'+this.task.taskID);
    xhr.send();
        
    }

    backward = ()=>{
        this.onLoad();
        let xhr = new XMLHttpRequest();
        xhr.addEventListener('readystatechange', ()=>{
            if(xhr.readyState == 4){
                var response = JSON.parse(xhr.responseText);
                console.log(response.message);
                if(response.message == 'Tarea actualizada'){
                    if(this.onBackwardDone() != null){
                        this.onBackwardDone();
                    }
                } else {
                    alert('No se pudo atrasar la tarea');
                }
            }
        });
    xhr.open('GET', 'api/tasks/backwardstatus/'+this.task.taskID);
    xhr.send();
        
    }
    

}