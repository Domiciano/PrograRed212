const titleTF = document.getElementById("titleTF");
const infoTF = document.getElementById("infoTF");
const submitBtn = document.getElementById("submitBtn");
const tasksToDoContainer = document.getElementById("tasksToDoContainer");
const tasksDoingContainer = document.getElementById("tasksDoingContainer");
const tasksDoneContainer = document.getElementById("tasksDoneContainer");
const myModal = new bootstrap.Modal(document.getElementById('myModal'));


const getAllTasks = async ()=>{
    
    let responseToDo = await fetch("api/tasks/getbytype/1");
    let data = await responseToDo.json();

    let responseDoing = await fetch("api/tasks/getbytype/2");
    let dataDoing = await responseDoing.json();

    let responseDone = await fetch("api/tasks/getbytype/3");
    let dataDone = await responseDone.json();

    //console.log(data);
    tasksToDoContainer.innerHTML = "";
    for(let i in data){
        let taskToDo = data[i];
        let taskView = new TaskView(taskToDo);

        taskView.onLoad = () =>{
            let newCardToDo = taskView.renderLoad(1);
            
            //Se busca el hijo dado el id del contenedor a cambiar
            let oldChildrenToDo = tasksToDoContainer.querySelector(`div[id="${taskToDo.taskID}" ]`);
            
            //Reemplazamos el hijo viejo por el nuevo
            tasksToDoContainer.replaceChild(newCardToDo, oldChildrenToDo);
            }
        taskView.onDeleteDone = () => {
            getAllTasks();

        }
        taskView.onForwardDone = () => {
            getAllTasks();

        }
        taskView.onBackwardDone = () => {
            getAllTasks();

        }
        taskView.render(tasksToDoContainer, 1);
        
    }


    //console.log(dataDoing);
    tasksDoingContainer.innerHTML = "";
    for(let i in dataDoing){
        let taskDoing = dataDoing[i];
        let taskViewDoing = new TaskView(taskDoing);

        taskViewDoing.onLoad = () =>{
            let newCardDoing = taskViewDoing.renderLoad(2);
            
            //Se busca el hijo dado el id del contenedor a cambiar
            let oldChildrenDoing = tasksDoingContainer.querySelector(`div[id="${taskDoing.taskID}" ]`);
            
            //Reemplazamos el hijo viejo por el nuevo
            tasksDoingContainer.replaceChild(newCardDoing, oldChildrenDoing);
            }
        taskViewDoing.onDeleteDone = () => {
            getAllTasks();

        }
        taskViewDoing.onForwardDone = () => {
            getAllTasks();

        }
        taskViewDoing.onBackwardDone = () => {
            getAllTasks();

        }
        taskViewDoing.render(tasksDoingContainer, 2);
        
    }


    //console.log(dataDone);
    tasksDoneContainer.innerHTML = "";
    for (let i in dataDone) {
        let taskDone = dataDone[i];
        let taskViewDone = new TaskView(taskDone);
        //Cuando la eliminacion finalize yo quiero que haga lo siguiente:
        taskViewDone.onLoad = () =>{
        let newCardDone = taskViewDone.renderLoad(3);
        
        //Se busca el hijo dado el id del contenedor a cambiar
        let oldChildrenDone = tasksDoneContainer.querySelector(`div[id="${taskDone.taskID}" ]`);

        //Reemplazamos el hijo viejo por el nuevo
        tasksDoneContainer.replaceChild(newCardDone, oldChildrenDone);
        }
        taskViewDone.onDeleteDone = () => {
            getAllTasks();

        }
        taskViewDone.onForwardDone = () => {
            getAllTasks();

        }
        taskViewDone.onBackwardDone = () => {
            getAllTasks();

        }
        taskViewDone.render(tasksDoneContainer, 3);      
    }
}

getAllTasks();


const postTask = async ()=>{
    let postOk = 'Submit Task';

    if((titleTF.value.length !== 0) && (infoTF.value.length !== 0)){

        let task = {
            taskID: "",
            title:titleTF.value,
            info:infoTF.value
        };
        
        let json = JSON.stringify (task);
        //let obj = JSON.parse(json);
    
        let response = await fetch("api/tasks/create",
            {
                method: "POST",
                headers: {
                    "Content-Type":"application/json"
                },
                body: json
            }
        );
        if(response.ok){
            let data = await response.json();
            console.log(data);
            await getAllTasks();
            //Cambio el botón
            submitBtn.innerHTML = postOk;
        }

    } else {
        alert("Ingrese un título y un contenido para su tarea");
    }
    //Cambio el botón
    submitBtn.innerHTML = postOk;
}

submitBtn.addEventListener("click", (event)=>{
    event.preventDefault();
    //Cambio el botón
    let spinner = '<button class="btn btn-primary" type="button" disabled><span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>Loading...</button>';
    submitBtn.innerHTML = spinner;
    postTask();
});