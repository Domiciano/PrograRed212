const nameTF = document.getElementById('nameTF');
const DescTF = document.getElementById('DescTF');
const addBtn = document.getElementById('addBtn');
const toDoCol = document.getElementById('toDoCol');
const DoingCol = document.getElementById('DoingCol');
const DoneCol = document.getElementById('DoneCol');

const getAllTasks = async ()=>{
    let response = await fetch("api/tasks/getall");
    let data = await response.json();
    console.log(data);
    toDoCol.innerHTML = "<p>To-Do</p>";
    DoingCol.innerHTML = "<p>Doing</p>";
    DoneCol.innerHTML = "<p>Done</p>";
    for(let i in data){
        let task = data[i];
        let taskView = new TaskView(task);
        switch (task.state) {
            case 1:
                taskView.render(toDoCol);
                break;
            case 2:
                taskView.render(DoingCol);
                break;
            case 3:
                taskView.render(DoneCol);
                break;
        }
    }
}
getAllTasks();

const postTask = async ()=>{
    let currentdate = new Date();
    let datetime = "" + currentdate.getDate() + "/"
        + (currentdate.getMonth()+1)  + "/"
        + currentdate.getFullYear() + "  "
        + currentdate.getHours() + ":"
        + currentdate.getMinutes() + ":"
        + currentdate.getSeconds();
    let task = {//id, String nombre, String descripcion, String fecha, String state
        id: 0,
        nombre:nameTF.value,
        descripcion:DescTF.value,
        fecha:datetime,
        state:'1'
    };
    let json = JSON.stringify(task);
    //let obj = JSON.parse(json);

    let response = await fetch("api/tasks/create",
        {
            method: "POST",
            headers: {
                "Content-Type":"application/json"
            },
            body: json
        }
    );
    if(response.ok){
        //let data = await response.json();
      //  console.log(data);
        getAllTasks();
        nameTF.value="";
        DescTF.value="";
    }
}

addBtn.addEventListener("click", (event)=>{
    event.preventDefault();
    postTask();
});
