class TaskView {


    //State
    constructor(task) {
        this.task = task;
    }


    //Metodos
    render = (container) => {

        //String -> HTML DOM

        let div = document.createElement("div"); //DOM

        let html = `<div class="card" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title">${this.task.nombre}</h5>
    <h6 class="card-subtitle mb-2 text-muted">${this.task.fecha}</h6>
    <p class="card-text">${this.task.descripcion}</p>`
        switch (this.task.state) {
            case 1:
                html += `<button type="button" id="deleteBtn${this.task.id}" class="btn btn-danger">X</button>
                    <button type="button"  id="advanceBtn${this.task.id}" class="btn btn-primary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z"/>
                        </svg>
                    </button>`
                break;
            case 2:
                html += `
                    <button type="button" id="backBtn${this.task.id}" className="btn btn-warning">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                             className="bi bi-arrow-left" viewBox="0 0 16 16">
                            <path fill-rule="evenodd"
                                  d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
                        </svg>
                    </button>
                    <button type="button" id="deleteBtn${this.task.id}" class="btn btn-danger">X</button>
                    <button type="button" id="advanceBtn${this.task.id}"  class="btn btn-primary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z"/>
                        </svg>
                    </button>`
                break;
            case 3:
                html += `
                    <button type="button" id="backBtn${this.task.id}" className="btn btn-warning">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-arrow-left" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
                        </svg>
                    </button>
                    <button type="button" id="deleteBtn${this.task.id}" class="btn btn-danger">X</button>`
                break;
        }
        html += `</div></div>`;
        div.innerHTML = html;
        let card = div.firstChild; // <div class="card">...</div> DOM HTML
        container.appendChild(card);

        //Eventos a la card
        let backBtn;
        let deleteBtn;
        let advanceBtn;
        switch (this.task.state) {
            case 1:
                deleteBtn = document.getElementById("deleteBtn" + this.task.id);
                advanceBtn = document.getElementById("advanceBtn" + this.task.id);
                break;
            case 2:
                backBtn = document.getElementById("backBtn" + this.task.id);
                deleteBtn = document.getElementById("deleteBtn" + this.task.id);
                advanceBtn = document.getElementById("advanceBtn" + this.task.id);
                break;
            case 3:
                backBtn = document.getElementById("backBtn" + this.task.id);
                deleteBtn = document.getElementById("deleteBtn" + this.task.id);
                break;
        }

        if (backBtn) {
            backBtn.addEventListener("click", async (e) => {
                e.preventDefault();
                this.task.state--;
                let json = JSON.stringify(this.task);
                let response = await fetch("api/tasks/edit",
                    {
                        method: "PUT",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: json
                    }
                );
                if (response.ok) {
                    console.log("response: "+response);
                    //let data = await response.json();
                    //console.log(data);
                    getAllTasks();
                }
            });
        }
        if (deleteBtn) {
            deleteBtn.addEventListener("click", async (e) => {
                e.preventDefault();
                let json = JSON.stringify(this.task);
                let response = await fetch("api/tasks/delete",
                    {
                        method: "DELETE",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: json
                    }
                );
                if (response.ok) {
                   // let data = await response.json();
                   // console.log(data);
                    getAllTasks();
                }
            });
        }
        if (advanceBtn) {
            advanceBtn.addEventListener("click", async (e) => {
                e.preventDefault();
                this.task.state++;
                let json = JSON.stringify(this.task);
                let response = await fetch("api/tasks/edit",
                    {
                        method: "PUT",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: json
                    }
                );
                if (response.ok) {
                  //  let data = await response.json();
                 //   console.log(data);
                    getAllTasks();
                }
            });
        }
    }

}