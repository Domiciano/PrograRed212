package providers;

import db.MySQL;
import entity.Task;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class TaskProvider {


    public ArrayList<Task> getAll() throws ClassNotFoundException, SQLException {
        MySQL db = new MySQL();
        db.connect();
        ArrayList<Task> tasks = new ArrayList<>();
        ResultSet resultSet = db.getDataBySQL("SELECT t.*, s.state FROM A00365583PFTask t, A00365583PFTaskState s WHERE t.stateId=s.id");
        while(resultSet.next()){//id, nombre,  descripcion,  fecha,  state) {
            tasks.add(new Task(
                    resultSet.getInt(1),
                    resultSet.getString(2),
                    resultSet.getString(3),
                    resultSet.getString(4),
                    resultSet.getInt(5)
            ));
        }
        db.close();
        return tasks;
    }

    public void create(Task task) throws ClassNotFoundException, SQLException {
        MySQL db = new MySQL();
        db.connect();
        String sql = "INSERT INTO `A00365583PFTask`(`name`, `descripcion`, `fecha`, `stateId`) VALUES ('[value-1]','[value-2]','[value-3]',[value-4])";
        sql = sql.replace("[value-1]",task.getNombre());
        sql = sql.replace("[value-2]",task.getDescripcion());
        sql = sql.replace("[value-3]",task.getFecha());
        sql = sql.replace("[value-4]",""+task.getState());
        db.commandSQL(sql);
    }

    public void edit(Task task) throws ClassNotFoundException, SQLException {
        MySQL db = new MySQL();
        db.connect();
        String sql = "UPDATE A00365583PFTask SET stateId=[value-1] WHERE id=[value-2]";
        sql = sql.replace("[value-1]",""+task.getState());
        sql = sql.replace("[value-2]",""+task.getId());
        db.commandSQL(sql);
    }
    public void delete(Task task) throws ClassNotFoundException, SQLException {
        MySQL db = new MySQL();
        db.connect();
        String sql = "DELETE FROM A00365583PFTask WHERE id=[value-1]";
        sql = sql.replace("[value-1]",""+task.getId());
        db.commandSQL(sql);
    }
}

